<?php

$conn = mysqli_connect("localhost", "root", "", "gym");
$json = json_decode(file_get_contents('php://input'), true);
if ($json == null) {
    $json = $_REQUEST;
}
$data = array();
switch ($json['type']) {
    case 'get_all_players':
        $select = "select * from users";
        $q = mysqli_query($conn, $select);
        while ($row = mysqli_fetch_assoc($q)) {
            $data[] = $row;
        }
        break;
    case 'sign_in':
        $email = $json['email'];
        $select = "select * from users where E_mail=$email";
        $q = mysqli_query($conn, $select);
        $row = mysqli_fetch_assoc($q);
        if (!empty($row)) {
            $data[] = $row;
        } else if (empty($row)) {
            $data[] = "user in not exisst";
        }
        break;
    case 'register':
        $name = $json['name'];
        $email = $json['email'];
        $pass = $json['pass'];
        $select = "select * from users where E_mail=$email";
        $q = mysqli_query($conn, $select);
        $fetch = mysqli_fetch_assoc($q);
        if (empty($fetch)) {
            $insert = "insert into users(user_name,E_mail,pass)values($name,$email,$pass)";
            $q2 = mysqli_query($conn, $insert);
            $s = "select * from users where E_mail=$email";
            $qr = mysqli_query($conn, $s);
            $row = mysqli_fetch_assoc($qr);
            $data[] = $row;
        } else if (!empty($fetch)) {
            $data[] = "the user is already exist";
        }
        break;
    case 'edit_gender_birthadte':
        $id = $json['id'];
        $gender = $json['gender'];
        $birth_date = $json['birth_date'];

        if (!empty($birth_date) and ! empty($gender)) {
            $edit = "update users set birth_date=$birth_date , gender=$gender where user_id=$id";
            $query = mysqli_query($conn, $edit);
            $select = "select birth_date,gender from users where user_id=$id";
            $qq = mysqli_query($conn, $select);
            $f = mysqli_fetch_assoc($qq);
            $data[] = $f;
        }
        break;
    case'edit_name':
        $id = isset($json['id']) ? $json['id'] : '""';
        $name = isset($json['name']) ? $json['name'] : '""';

        if (!empty($id)) {
            $update = "update users set user_name=$name where user_id=$id";
            $q = mysqli_query($conn, $update);
            $select = "select user_name from users where user_id=$id";
            $qq = mysqli_query($conn, $select);
            $f = mysqli_fetch_assoc($qq);
            $data[] = $f;
        }
        break;

    case'get_user':
        $id = isset($json['id']) ? $json['id'] : '""';
        $select = "select * from users where user_id=$id";
        $query = mysqli_query($conn, $select);
        $fetch = mysqli_fetch_assoc($query);

        if (!empty($fetch)) {
            $data[] = $fetch;
        } else if (empty($fetch)) {
            $data[] = "user not exsit";
        }
        break;
    case 'add_img':
        $file = $_FILES;
        $tmp_name = $_FILES["tmp_name"];

        $name = basename($_FILES["name"]);
//$data=$_FILES;
        move_uploaded_file($tmp_name, "/tmp/" . $name);
        $id = $json['id'];
        $alter = "update users set imaje=$name where user_id=$id";
        $up = mysqli_query($conn, $alter);


        break;
    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////
    case'get_all_gyms':
        $select = "select * from gym";
        $q = mysqli_query($conn, $select);
        while ($row = mysqli_fetch_assoc($q)) {
            $data[] = $row;
        }
        break;
    case'register_gym':
        $gym_name = $json['name'];
        $email = $json['email'];
        $pass = $json['pass'];
        $lat = $json['lat'];
        $lng = $json['lng'];
        $gym_num = $json['gym_num'];
        $visit_price = $json['visit_price'];
        // echo $gym_name;
        $select = "select * from gym where gym_email=$email";
        $q = mysqli_query($conn, $select);
        $fet = mysqli_fetch_assoc($q);
        if (empty($fet)) {
            $insert = "insert into gym(gym_name,gym_email,pass,lat,lng,gym_num,visit_price)values($gym_name,$email,$pass,$lat,$lng,$gym_num,$visit_price)";
            $q = mysqli_query($conn, $insert);
            $xx = "select gym_id from gym where gym_email=$email";
            $dd = mysqli_query($conn, $xx);
            $fetch = mysqli_fetch_assoc($dd);
            $data[] = $fetch;
//            $f = $fetch["gym_id"];
//            $wc = "insert into gym_imges(gym_id)values($f)";
//            $x = mysqli_query($conn, $wc);
//            echo $f;
        } else if (!empty($fet)) {
            $data['error'] = "gym is already exist";
        }
        break;
    default:
        $data['error'] = 'invaled type';
        break;
    case 'get_gym' :
        $gym_id = $json['gym_id'];
        $userId = isset($json['user_id']) ? $json['user_id'] : '';
        $select = "select * from gym where gym_id = $gym_id";
        $query = mysqli_query($conn, $select);
        $fetch = mysqli_fetch_assoc($query);
        if ($userId != '') {
            $selectRate = "select * from gym_rate where gym_id = $gym_id and user_id = $userId";
            $queryRate = mysqli_query($conn, $selectRate);
            $fetchRate = mysqli_fetch_assoc($queryRate);
        }
        $fetch['rate'] = !empty($fetchRate) ? $fetchRate['rate'] : 0;
        if (!empty($fetch)) {
            $data[] = $fetch;
        } else if (empty($fetch)) {
            $data[] = "gym not exsit";
        }
        break;

    case 'add_edit_img':
        $gym_id = $json['gym_id'];
        $gym_img = $json['gym_img'];

        $edit = "update gym set gym_img=$gym_img where gym_id=$gym_id";
        $q = mysqli_query($conn, $edit);
        $data[] = $gym_id;
        $data[] = $gym_img;
        $data[] = $edit;
//        echo"update img";
        break;
    case 'edit_opentime':
        $gym_id = $json['gym_id'];
        $open_time = $json['open_time'];

        $edit = "update gym set open_time=$open_time where gym_id=$gym_id";
        $q = mysqli_query($conn, $edit);
//        echo"update open_time";
        break;
    case 'edit_closetime':
        $gym_id = $json['gym_id'];
        $close_time = $json['close_time'];

        $edit = "update gym set close_time=$close_time where gym_id=$gym_id";
        $q = mysqli_query($conn, $edit);
//        echo"update close_time";
        break;
    case 'edit_services':
        $gym_id = $json['gym_id'];
        $steem = $json['steem'];
        $pool = $json['pool'];
        $jacuzzi = $json['jacuzzi'];
        $sauna = $json['sauna'];
//        echo $sauna;
        $edit = "update gym set steem = $steem, pool =$pool , jacuzzi =$jacuzzi , sauna = $sauna where gym_id=$gym_id";
        $q = mysqli_query($conn, $edit);
//        echo"update services";
        break;
    case 'gym_sign_in':
        $gym_email = $json['email'];
        $pass = $json['pass'];

        $select = "select * from gym  where gym_email=$gym_email and pass=$pass";
        $q = mysqli_query($conn, $select);
        $row = mysqli_fetch_assoc($q);
        if (!empty($row)) {

//            $data[0] = $row;
            $data[] = $row;
        } else if (empty($row)) {
            $data[] = "gym is not exisst";
        }
        break;
    case'add_imge_gym':
        $gym_id = $json['gym_id'];
        $gym_imge = $json['gym_imge'];
        $select = "select * from gym_imges where gym_id=$gym_id";
        $q = mysqli_query($conn, $select);
        $fetch = mysqli_fetch_assoc($q);
        if (empty($fetch)) {
            $select2 = "insert into gym_imges(gym_id) values($gym_id)";
            $q2 = mysqli_query($conn, $select2);
            $select = "select * from gym_imges where gym_id=$gym_id";
            $q = mysqli_query($conn, $select);
            $fetch = mysqli_fetch_assoc($q);
        }

        $dat[0] = $fetch;


        foreach ($dat[0] as $key => $value) {
            if ($value == null) {

                $i = "update gym_imges set $key=$gym_imge where gym_id=$gym_id";
                $e = mysqli_query($conn, $i);
//                prin_r($dat);
                break;
            }
        }
        break;
    case 'delete_image':
        $gym_id = $json['gym_id'];
        $imge = $json['gym_imge'];

        $select = "select * from gym_imges where gym_id = $gym_id";
        $q = mysqli_query($conn, $select);
        $fetch = mysqli_fetch_assoc($q);
        $data[0] = $fetch;

        foreach ($data[0] as $key => $value) {

            if ($value == $imge) {
//    echo$key.$value;  




                $delete = "update gym_imges set $key=null where gym_id=$gym_id";
                $q = mysqli_query($conn, $delete);

                break;
            }
        }


    case 'rate':


        $rate = $json['rate'];
        $gym_id = $json['gym_id'];
        if (isset($gym_id)) {
            $x = "insert into gym_rate(gym_id,rate)values($gym_id,$rate)";
            $q = mysqli_query($conn, $x);
            $i = 1;
            ++$i;
//            echo$i;
            break;
        }
    case 'getImageList':
        $gym_id = $json['gym_id'];

        $select = "select * from gym_imges where gym_id = $gym_id";
        $q = mysqli_query($conn, $select);
        $fetch = mysqli_fetch_assoc($q);
        $data[0] = $fetch;

        break;
    case 'get_rate':
        $i = 0;
        $sum = 0;
        $rate;
        $gym_id = $json['gym_id'];
        $select = "select gym_rate from rate where gym_id=$gym_id";
        $q = mysqli_query($conn, $select);
        while ($row = mysqli_fetch_assoc($q)) {

            $sum += $row['rate'];
            $i++;
        }
        $rate = $sum / $i;
        $data[] = $rate;
        break;
    case'get_all_vist_by_id':
        $gym_id = $json['gym_id'];
        $select = "select * from visit,users where gym_id=$gym_id and visit.user_id=users.user_id";
        $q = mysqli_query($conn, $select);
        while ($row = mysqli_fetch_assoc($q)) {
            $data[] = $row;
        }
        break;
    case'get_all_vist_by_user_id':
        $user_id = $json['user_id'];
        $select = "select * from visit,users where visit.user_id=$user_id and visit.user_id=users.user_id";
        $q = mysqli_query($conn, $select);
        while ($row = mysqli_fetch_assoc($q)) {
            $data[] = $row;
        }
        break;
    case'status':
        $gym_id = $json['gym_id'];
        $user_id = $json['user_id'];

        $select = "select * from visit where gym_id=$gym_id and user_id=$user_id";
        $q = mysqli_query($conn, $select);
        $fetch = mysqli_fetch_assoc($q);
        if (empty($fetch)) {
            $x = "insert into visit(gym_id,user_id,status) values($gym_id,$user_id,1)";
            $q = mysqli_query($conn, $x);
        } else {
            $update = "update visit set status=1 where gym_id=$gym_id and user_id=$user_id";
            $q = mysqli_query($conn, $update);
        }
        break;
    case 'delete_visit':
        $gym_id = $json['gym_id'];
        $user_id = $json['user_id'];
        $delete = "delete from visit where gym_id=$gym_id and user_id=$user_id";
        $q = mysqli_query($conn, $delete);
        break;
    case 'getGymRateById':
        $gym_id = $json['gym_id'];
        $select = "select count(*) as count,sum(rate) as rate from gym_rate where gym_id=$gym_id";
        $q = mysqli_query($conn, $select);
        $row = mysqli_fetch_assoc($q);
        $data[] = $row;
        break;
    case 'add_rate':
        $user_id = $json['user_id'];
        $rate = $json['rate'];
        $gym_id = $json['gym_id'];

        $select = "select * from gym_rate where gym_id=$gym_id and user_id=$user_id";
        $q = mysqli_query($conn, $select);
        $fetch = mysqli_fetch_assoc($q);
        if (empty($fetch)) {
            $x = "insert into gym_rate(gym_id,rate,user_id) values($gym_id,$rate,$user_id)";
            $q = mysqli_query($conn, $x);
        } else {
            $update = "update gym_rate set rate =$rate where user_id=$user_id and gym_id=$gym_id ";
            $q = mysqli_query($conn, $update);
        }
        break;
}
header('Content-Type: application/json');
print json_encode($data);
exit();
?>
 